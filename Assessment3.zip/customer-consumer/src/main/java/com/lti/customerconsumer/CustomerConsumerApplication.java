package com.lti.customerconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;

import com.lti.customerconsumer.controller.CustomerController;


@SpringBootApplication
public class CustomerConsumerApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(CustomerConsumerApplication.class, args);
		CustomerController consumerController=ctx.getBean(CustomerController.class);
		System.out.println(consumerController);
		consumerController.getCustomer();
	}

}
